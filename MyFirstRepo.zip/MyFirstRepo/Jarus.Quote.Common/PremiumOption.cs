﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jarus.Quote.Common
{
    public class PremiumOption
    {
        public string Text { set; get; }
        public string Value { set; get; }
    }
}

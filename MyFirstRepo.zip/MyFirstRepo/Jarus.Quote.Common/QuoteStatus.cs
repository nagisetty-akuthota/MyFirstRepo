﻿using System;

namespace Jarus.Quote.Common
{
    public enum QuoteStatus
    {
        Pending = 0, 
        Issued = 1
    }
}

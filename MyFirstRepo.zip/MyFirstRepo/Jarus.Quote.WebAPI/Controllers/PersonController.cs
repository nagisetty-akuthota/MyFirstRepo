﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Jarus.Quote.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Jarus.Quote.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        private readonly ILogger<PersonController> _logger;
        private readonly IConfiguration _Configure;
        public PersonController(ILogger<PersonController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _Configure = configuration;
        }

        // GET: api/<PersonController>
        [HttpGet("GetPersons")]
        public async Task<IEnumerable<Person>> Get()
        {
            try
            {
                return await MockData.GetDummyPersonData().ConfigureAwait(false);
            }
            catch (Exception ee)
            {
                _logger.LogError(ee.Message);
                return null;
            }
        }

        // GET api/<PersonController>/5
        [HttpGet("GetPerson/{id}")]
        public async Task<Person> Get(int id)
        {
            try
            {
                var personList = await MockData.GetDummyPersonData().ConfigureAwait(false);
                return personList.FirstOrDefault(p => p.PersonId == id);
            }
            catch (Exception ee)
            {
                _logger.LogError(ee.Message);
                return null;
            }
        }

        [HttpGet("FindPeople/{firstname}/{lastname}")]
        public async Task<IEnumerable<Person>> GetPersonsByFirstOrLastName(string firstname, string lastname)
        {
            try
            { 
            StringComparison stringComparison = StringComparison.CurrentCultureIgnoreCase;
                var personList = await MockData.GetDummyPersonData().ConfigureAwait(false);
                return personList.Where(p => (p.FirstName.IndexOf(firstname, stringComparison) > 0 || p.LastName.IndexOf(lastname, stringComparison) > 0));
            }
            catch (Exception ee)
            {
                _logger.LogError(ee.Message);
                return null;
            }
        }
    }
}

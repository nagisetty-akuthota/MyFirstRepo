﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Jarus.Quote.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Jarus.Quote.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuoteController : ControllerBase
    {
        private readonly ILogger<QuoteController> _logger;

        public QuoteController(ILogger<QuoteController> logger)
        {
            _logger = logger;
        }

        // GET: api/<PersonController>
        [HttpGet("GetQuotes")]
        public async Task<IEnumerable<Quote.Model.Quote>> Get()
        {
            try
            {
                return await MockData.GetDummyQuoteData().ConfigureAwait(false);
            }
            catch (Exception ee)
            {
                _logger.LogError(ee.Message);
                return null;
            }
        }

        // GET api/<PersonController>/5
        [HttpGet("GetQuote/{id}")]
        public async Task<Quote.Model.Quote> Get(int id)
        {
            try
            {
                var quoteList = await MockData.GetDummyQuoteData().ConfigureAwait(false);
                return quoteList.FirstOrDefault(quote => quote.QuoteId == id);
            }
            catch (Exception ee)
            {
                _logger.LogError(ee.Message);
                return null;
            }
        }

        [HttpGet("GetAdditionalInsuredForQuote/{id}")]
        public async Task<IEnumerable<Quote.Model.Person>> GetPersonsByFirstOrLastName(int id)
        {
            try
            {
                var quoteList = await MockData.GetDummyQuoteData().ConfigureAwait(false);
                return quoteList.FirstOrDefault(quote => quote.QuoteId == id).AdditionalInsureds;
            }
            catch (Exception ee)
            {
                _logger.LogError(ee.Message);
                return null;
            }
        }

        [HttpPost("AddAdditionalInsuredForQuote")]
        public async Task<Quote.Model.Quote> AddPersonsByFirstOrLastName(int quoteid, Person person)
        {
            try
            {
                return await MockData.AddAdditionalInsuredToQuote(quoteid, person).ConfigureAwait(false);
            }
            catch (Exception ee)
            {
                _logger.LogError(ee.Message);
                return null;
            }
        }
    }
}

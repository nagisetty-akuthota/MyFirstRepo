﻿using Jarus.Quote.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jarus.Quote.Model
{
    public static class MockData
    {
        private static List<Quote> QuotesList { get; set; }
        private static List<Person> PersonList { set; get; }
        static MockData()
        {
            QuotesList = new List<Quote>();
            for (int i = 1; i < 10; i++)
            {
                var additionalInsured = new Person();
                additionalInsured.PersonId = i;
                additionalInsured.FirstName = "First Name " +i.ToString();
                additionalInsured.LastName = "Last Name " + i.ToString();
                additionalInsured.DateOfBirth = DateTime.Now.AddYears(-18).AddYears(-i);
                additionalInsured.Coverage = i.ToString("00%");
                QuotesList.Add(new Quote() { QuoteId = i, QuoteNumber = i.ToString("QUOTE#000"), QuoteStatus = Common.QuoteStatus.Pending, AdditionalInsureds = new List<Person>() { additionalInsured }, Applicant = "Jarus Tech # "+i.ToString() });
            }

            PersonList = new List<Person>();
            for (int i = 1; i < 10; i++)
            {
                PersonList.Add(new Person() { PersonId = i, FirstName = "First" + i.ToString(), LastName = "Last" + i.ToString(), DateOfBirth = DateTime.Now.AddYears(-i), Coverage = i.ToString("00") + "%" });
            }
        }

        public static async Task<List<String>> GetQuoteStatus()
        {
            return await Task.Run(() => Enum.GetNames(typeof(QuoteStatus)).ToList());
        }
        public static async Task<List<PremiumOption>> GetQuotePremiumOptions()
        {
            var PremiumOptionList = new List<PremiumOption>();
            PremiumOptionList.Add(new PremiumOption() { Text ="Basic", Value = "$650" });
            PremiumOptionList.Add(new PremiumOption() { Text = "Preferred", Value = "$850" });
            PremiumOptionList.Add(new PremiumOption() { Text = "Premium", Value = "$1050" });
            return await Task.Run(() => PremiumOptionList);
        }

        public static async Task<List<Quote>> GetDummyQuoteData()
        {
            return await Task.Run(() => QuotesList);
        }

        public static async Task<List<Person>> GetDummyPersonData()
        {
            return await Task.Run(() => PersonList);
        }

        public static async Task<IEnumerable<Person>> Search(string firstName, string lastName)
        {
            return await Task.Run(() => PersonList.Where(p => (p.FirstName != null && p.LastName != null) && (firstName != null && (p.FirstName.ToLower().Contains(firstName.ToLower())) || (lastName != null && p.LastName.ToLower().Contains(lastName.ToLower())))));
        }

        public static async Task<Quote> AddAdditionalInsuredToQuote(int quoteid, Person person)
        {
            var quote = QuotesList.FirstOrDefault(q => q.QuoteId == quoteid);
            quote.AdditionalInsureds.Add(person);
            return await Task.Run(() => quote);
        }
        public static async Task<Person> UpdatePerson(Person updatingPerson)
        {
            var deletingPerson = PersonList.FirstOrDefault(p => p.PersonId == updatingPerson.PersonId);
            PersonList.Remove(deletingPerson);
            PersonList.Add(updatingPerson);
            return await Task.Run(() => updatingPerson);
        }

        public static async Task<Person> DeletePerson(int personId)
        {
            var deletingPerson = PersonList.FirstOrDefault(p => p.PersonId == personId);
            PersonList.Remove(deletingPerson);
            return await Task.Run(() => deletingPerson);
        }

        public static async Task<Person> AddPerson(Person addPerson)
        {
            PersonList.Add(addPerson);
            return await Task.Run(() => addPerson);
        }

        public static async Task<Quote> UpdateQuote(Quote updatingQuote)
        {
            var deletingQuote = QuotesList.FirstOrDefault(p => p.QuoteId == updatingQuote.QuoteId);
            QuotesList.Remove(deletingQuote);
            QuotesList.Add(updatingQuote);
            return await Task.Run(() => updatingQuote);
        }

        public static async Task<Quote> DeleteQuote(int quoteId)
        {
            var deletingPerson = QuotesList.FirstOrDefault(p => p.QuoteId == quoteId);
            QuotesList.Remove(deletingPerson);
            return await Task.Run(() => deletingPerson);
        }

        public static async Task<Quote> AddQuote(Quote addQuote)
        {
            QuotesList.Add(addQuote);
            return await Task.Run(() => addQuote);
        }

        public static async Task<IEnumerable<Person>> AddPersonToAdditionalInsured(Person person)
        {
            QuotesList.FirstOrDefault(q => q.QuoteId == 1).AdditionalInsureds.Add(person);
            return await Task.Run(()=> QuotesList.FirstOrDefault(q => q.QuoteId == 1).AdditionalInsureds);
        }
        public static async Task<IEnumerable<Person>> GetPersonToAdditionalInsured()
        {
            return await Task.Run(() => QuotesList.FirstOrDefault(q => q.QuoteId == 1).AdditionalInsureds);
        }
    }
}
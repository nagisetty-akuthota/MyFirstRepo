﻿
using System;
using System.ComponentModel.DataAnnotations;

namespace Jarus.Quote.Model
{
    public class Person
    {
        public int PersonId { set; get; }
        [Display(Name = "First Name")]
        public string FirstName { set; get; }
        [Display(Name = "Last Name")]
        public string LastName { set; get; }
        [Display(Name = "Full Name")]
        public string FullName { get { return FirstName + " " + LastName; } }
        [Display(Name = "Coverage")]
        public string Coverage { set; get; }
        [Display(Name = "Date Of Birth")]
        public DateTime DateOfBirth { set; get; }
    }
}

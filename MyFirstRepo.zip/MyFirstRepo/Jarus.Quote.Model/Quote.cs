﻿using Jarus.Quote.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Jarus.Quote.Model
{
    public class Quote
    {
        public int QuoteId { set; get; }
        [Display(Name = "Quote Number")]
        public string QuoteNumber { set; get; }
        [Display(Name = "Quote Status")]
        public QuoteStatus QuoteStatus { set; get; }
        [Display(Name = "Applicant")]
        public string Applicant { set; get; }
        //public Dictionary<PremiumOption, string> PremiumOptions { get; }
        [Display(Name = "Premium Options")]
        public PremiumOption PremiumOption { set; get; }
        [Display(Name = "Quote Date")]
        public DateTime QuoteDate { set; get; }
        [Display(Name = "Quote Effective Date")]
        public DateTime QuoteEffectiveDate { set; get; }
        [Display(Name = "Additional Insureds")]
        public List<Person> AdditionalInsureds { set; get; }
    }
}

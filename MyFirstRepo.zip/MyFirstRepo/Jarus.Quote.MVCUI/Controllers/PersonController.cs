﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Jarus.Quote.MVCUI.Data;
using Jarus.Quote.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Jarus.Quote.MVCUI.Controllers
{
    public class PersonController : Controller
    {
        private readonly ILogger<PersonController> _logger;
        private readonly IConfiguration _Configure;
        public PersonController(ILogger<PersonController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _Configure = configuration;
        }

        // GET: Person
        public async Task<IActionResult> Index()
        {
            return View(await MockData.GetDummyPersonData().ConfigureAwait(false));
        }

        // GET: Person/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var persons = await MockData.GetDummyPersonData().ConfigureAwait(false);
            var person = persons.FirstOrDefault(m => m.PersonId == id);
            if (person == null)
            {
                return NotFound();
            }

            return View(person);
        }

        // GET: Person/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Person/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PersonId,FirstName,LastName,Coverage,DateOfBirth")] Person person)
        {
            if (ModelState.IsValid)
            {
                var addedPerson = await MockData.AddPerson(person).ConfigureAwait(false);
                return RedirectToAction(nameof(Index));
            }
            return View(person);
        }

        // GET: Person/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var persons = await MockData.GetDummyPersonData().ConfigureAwait(false);
            var person = persons.FirstOrDefault( p => p.PersonId == id);
            if (person == null)
            {
                return NotFound();
            }
            return View(person);
        }

        // POST: Person/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PersonId,FirstName,LastName,Coverage,DateOfBirth")] Person person)
        {
            if (id != person.PersonId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var persons = await MockData.UpdatePerson(person).ConfigureAwait(false);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await PersonExists(person.PersonId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(person);
        }

        // GET: Person/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            Person deletingPerson = null;
            if (id.HasValue)
                deletingPerson = await MockData.DeletePerson(id.Value).ConfigureAwait(false);
            if (deletingPerson == null)
            {
                return NotFound();
            }

            return View(deletingPerson);
        }

        // POST: Person/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var persons = await MockData.GetDummyPersonData().ConfigureAwait(false);
            var person = persons.FirstOrDefault(m => m.PersonId == id);
            persons.Remove(person);
            return RedirectToAction(nameof(Search));
        }

        private async Task<bool> PersonExists(int id)
        {
            var persons = await MockData.GetDummyPersonData().ConfigureAwait(false);
            return persons.Any(e => e.PersonId == id);
        }
        // GET: Person
        public async Task<IActionResult> Search()
        {
            return View(await MockData.GetDummyPersonData().ConfigureAwait(false));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Search([Bind("firstName,lastName,search")] string firstName, string lastName, string search)
        {
            return View(await MockData.Search(firstName, lastName).ConfigureAwait(false));
        }

        public async Task<IActionResult> Select(int? id)
        {
            var persons = await MockData.GetDummyPersonData().ConfigureAwait(false);
            var person = persons.FirstOrDefault(p => p.PersonId == id);
            var additionalInsuredList = await Task.Run(() => MockData.AddPersonToAdditionalInsured(person)).ConfigureAwait(false);
            return View("AdditionalInsured", additionalInsuredList);
        }

        // GET: Person
        public async Task<IActionResult> AdditionalInsured()
        {
            var additionalInsuredList = await Task.Run(() => MockData.GetPersonToAdditionalInsured()).ConfigureAwait(false);
            return View(additionalInsuredList);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Jarus.Quote.MVCUI.Data;
using Jarus.Quote.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Jarus.Quote.MVCUI.Controllers
{
    public class QuotesController : Controller
    {
        private readonly ILogger<QuotesController> _logger;
        private readonly IConfiguration _Configure;
        public QuotesController(ILogger<QuotesController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _Configure = configuration;
        }

        // GET: Quotes
        public async Task<IActionResult> Index()
        {
            return View(await MockData.GetDummyQuoteData());
        }

        // GET: Quotes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var quotes = await MockData.GetDummyQuoteData().ConfigureAwait(false);
            var quote = quotes.FirstOrDefault(m => m.QuoteId == id);
            if (quote == null)
            {
                return NotFound();
            }

            return View(quote);
        }

        // GET: Quotes/Create
        public async Task<IActionResult> Create()
        {
            ViewBag.QuoteStatusList = await MockData.GetQuoteStatus();
            ViewBag.QuotePremiumOptionsList = await MockData.GetQuotePremiumOptions();
            return View();
        }

        // POST: Quotes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("QuoteId,QuoteNumber,QuoteStatus,Applicant,PremiumOption,QuoteDate,QuoteEffectiveDate")] Jarus.Quote.Model.Quote quote)
        {
            if (ModelState.IsValid)
            {
                var addedQuote = await MockData.AddQuote(quote);
                return RedirectToAction(nameof(Index));
            }
            return View(quote);
        }

        // GET: Quotes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            //if (id == null)
            //{
            //    return NotFound();
            //}
            if(id == null)
            {
                id = 1;
            }

            ViewBag.QuoteStatusList = await MockData.GetQuoteStatus();
            ViewBag.QuotePremiumOptionsList = await MockData.GetQuotePremiumOptions();
            var quotes = await MockData.GetDummyQuoteData().ConfigureAwait(false);
            var quote = quotes.FirstOrDefault(m => m.QuoteId == id);
            if (quote == null)
            {
                return NotFound();
            }
            return View(quote);
        }

        // POST: Quotes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("QuoteId,QuoteNumber,QuoteStatus,Applicant,PremiumOption,QuoteDate,QuoteEffectiveDate")] Jarus.Quote.Model.Quote quote)
        {
            if (id != quote.QuoteId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var updatedQuote = MockData.UpdateQuote(quote);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (! await QuoteExists(quote.QuoteId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(quote);
        }

        // GET: Quotes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var quotes = await MockData.GetDummyQuoteData().ConfigureAwait(false);
            var quote = quotes.FirstOrDefault(m => m.QuoteId == id);
            if (quote == null)
            {
                return NotFound();
            }

            return View(quote);
        }

        // POST: Quotes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var quote = await MockData.DeleteQuote(id);
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> QuoteExists(int id)
        {
            var quotes = await MockData.GetDummyQuoteData().ConfigureAwait(false);
            return quotes.Any(e => e.QuoteId == id);
        }
    }
}
